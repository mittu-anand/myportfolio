
 <section class="vbox">
      
      <header class="bg-primary header navbar navbar-fixed-top-xs">
        
        <div class="navbar-header">
          
         
          <a href="#" class="navbar-brand">
            Stack
          </a>
          
         
          
        </div>
        
        <ul class="nav navbar-nav">
          
          <li>
            
            <a href="<?php echo base_url();?>index.php/videos">
              
              <i class="fa fa-building-o">
              </i>
              
              <span class="font-bold">
               Videos
              </span>
              
            </a>
            
          </li>
         
        </ul>
       
      </header>
      
      <section>
        
        <section class="hbox stretch">
          
     
          <section id="content">
            
            <section class="wrapper">
             
            </section>
            
            
          </section>
          
          
        </section>
        
      </section>
      
    </section>
    