
<section id="content">
        
        <section class="vbox">
          
         
            
            <section class="hbox stretch">
			<section class="vbox">
                
				 <section class="scrollable wrapper">
				 <div class="spacer"></div>
<div class="row">
  
 
		
		<div class="col-sm-10 col-sm-offset-1">
<section class="vbox">
 <div class="m-b-lg text-center">
 
 <?php $lactive=$this->session->userdata('lactive'); ?>

  
  <p class="m-b-none"> 
<?php if($alphabets){foreach($alphabets as $alph) {?>  
    <a href="<?php echo base_url();?>index.php/celebfolio/celebrity_like?filter=<?php echo $alph->letter; ?>" class="alphabelts" rel="<?php echo $alph->letter; ?>"><span class="badge  <?php if($lactive==$alph->letter){ echo 'bg-warning';} else { echo 'bg-success';}?>">
      <?php echo $alph->letter; ?>
    </span></a> 
	<?php } } ?>
  </p>
  
</div>
 <?php if($allcelebs){ ?>
 <div class="col-sm-3 pull-right">
      
      <div class="input-group">
        
        <input type="text"  placeholder="Celebrity Name" class="input-sm form-control celebsearch">
        
        <span class="input-group-btn">
          
          <button type="button" class="btn btn-sm btn-default celebsearchbtn">
            Go!
          </button>
          
        </span>
        
      </div>
      
    </div>
<?php } ?>
</section>
<div class="spacer"></div>
        <div class="table-responsive">
  <?php if($allcelebs){ foreach($allcelebs as $allceleb) { ?>

    <div class="col-sm-4">
    <section class="panel panel-info">
  
  <div class="panel-body">
    
    <a class="thumb pull-right m-l" href="<?php echo base_url();?>index.php/celebfolio/celeb?id=<?php echo $allceleb->cid;?>&&name=<?php echo $allceleb->name;?>">
      
      <img class="img-circle"  style="height:50px;width:50px;" src="<?php echo base_url();?>uploads/celebs/<?php if($allceleb->images!=''){echo $allceleb->images; }else{ if($allceleb->gender=='M'){ echo "avatar_default.jpg";}else{echo "favatar_default.jpg";}  }?>">
      
    </a>
    
    <div class="clear">
      
      <a class="text-info" href="<?php echo base_url();?>index.php/celebfolio/celeb?id=<?php echo $allceleb->cid;?>&&name=<?php echo $allceleb->name;?>">
        <?php echo $allceleb->name; ?>
       
      </a>
      
      <small class="block text-muted">
        <?php 
	
		  $CI =& get_instance();
		  $followers=$CI->user_model->users_following($allceleb->cid);
		  if($followers==0)
		  {
			$flw='0 followers';
		  }
		   else if($followers==1)
		  {
			$flw='1 follower';
		  }
		  else
		  {
			$flw=$followers.' followers';
		  }
	      echo $flw;
	  ?>
      </small>
      
      <a class="btn btn-xs btn-success m-t-xs" href="#">
        <?php echo $allceleb->type; ?>
      </a>
      
    </div>
    
  </div>
  
</section>
    </div>
	<?php } }else {?>
	No results Found!
	<?php } ?>
  </div>    
  </div>
   
 
  
  
</div>
<div class="spacer"></div>
<div class="spacer"></div>
</section>
</section>
</section>
</section>
</section>
<style>
iframe
{
	width:100% !important;
}
</style>
<script src="<?php echo base_url();?>js/charts/sparkline/jquery.sparkline.min.js">
</script>
<script>
$('.celebsearchbtn').click(function()
{
srchval=$('.celebsearch').val();
location.href="<?php echo base_url();?>index.php/celebfolio/celebrity_like?filter="+srchval;
}
);
</script>