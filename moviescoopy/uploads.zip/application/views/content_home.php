
 
 <section id="content">
       <section id="main-slider" class="no-margin">
        <div class="carousel slide wet-asphalt">
            <ol class="carousel-indicators">
                <li data-target="#main-slider" data-slide-to="0" class="active"></li>
                <li data-target="#main-slider" data-slide-to="1"></li>
                <li data-target="#main-slider" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="item active" style="background-image: url(<?php echo base_url();?>images/slider/bg5.png)">
                     <div class="container">
                   <div class="row">
                            <div class="col-sm-6">
							
                                <div class="carousel-content centered">
								<div class="text-center wrapper">
          
          <div class="m-t-xl m-b-xl">
            
            <div class="text-uc h1 font-bold inline">
              
              <div class="pull-left m-r-sm text-white">
                You are now a
                <span class="text-warning">
                Star
                 
                </span>!
              </div>
              
            </div>
            
            <div class="h4 text-muted m-t-sm">
					<h2> Moviescoopy is your first step to Cinema.</h2>
                                    <h4>Make a portfolio page here,expose your skills and do more!</h4>
              <a class="btn btn-danger" href="">Make a Portfolio</a>&nbsp;&nbsp;<a class="btn btn-success " href="">How it works?</a>
			</div>
            
          </div>
          
        </div>
                                    
                                  
                                </div>
                            </div>
                            <div class="col-sm-6 hidden-xs">
                                <div class="centered">
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!--/.item-->
                <div class="item" style="background-image: url(<?php echo base_url();?>images/slider/bg8.png)">
				
                     <div class="container">
                        <div class="row">
                            <div class="col-sm-6" style="z-index:1000;">
                                <div class="carousel-content centered">
									<div class="text-center wrapper">
          
          <div class="m-t-xl m-b-xl">
            
            <div class="text-uc h1 font-bold inline">
              
              <div class="pull-left m-r-sm text-white">
                Latest and awaited
                <span class="text-warning">
                Movies
                 
                </span>!
              </div>
              
            </div>
            
            <div class="h4 text-muted m-t-sm">
					<h2>Get updated about movies from the very begining of their birth!</h2>
                                    <h4>See if you are given an opurtunity there!</h4>
              <a class="btn btn-danger" href="<?php echo base_url();?>index.php/moviefolio">Go to Moviefolio</a>&nbsp;&nbsp;<a class="btn btn-success " href="<?php echo base_url();?>index.php/reviews">Latest Movie Reviews</a>
                                </div>
            
          </div>
          
        </div>
                                   
							 </div>
                            </div>
                            <div class="col-sm-6 hidden-xs">
                                <div class="centered">
                                   
                                </div>
                            </div>
                        </div>
                    </div>
					
                </div><!--/.item-->
                <div class="item" style="background-image: url(<?php echo base_url();?>images/slider/bg1.png)">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="carousel-content centered">
								<div class="text-center wrapper">
          
          <div class="m-t-xl m-b-xl">
            
            <div class="text-uc h1 font-bold inline">
              
              <div class="pull-left m-r-sm text-white">
                It's all about
                <span class="text-warning">
                Cinema
                 
                </span>!
              </div>
              
            </div>
            
            <div class="h4 text-muted m-t-sm">
					<h2>Read, Know, Think, Share, Update!</h2>
                                    <h4>What new movies are about? What your favourite celebrity is up to?  What is happening around the cinema planet?</h4>
               <a class="btn btn-danger" href="<?php echo base_url();?>index.php/moviefolio">Moviescoopy Feeds</a>&nbsp;&nbsp;<a class="btn btn-success " href="<?php echo base_url();?>index.php/moviescoopy">Take a Moviescoopy Tour</a>
                                </div>
            
          </div>
          
        </div>
                                    
                            </div>
                            <div class="col-sm-6 hidden-xs">
                                <div class="centered">
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!--/.item-->
            </div><!--/.carousel-inner-->
        </div><!--/.carousel-->
        <a class="prev hidden-xs" href="#main-slider" data-slide="prev">
            <i class="fa fa-arrow-left"></i>
        </a>
        <a class="next hidden-xs" href="#main-slider" data-slide="next">
            <i class="fa fa-arrow-right"></i>
        </a>
    </section><!--/#main-slider-->
     
      <div id="newsletter" class="bg-white clearfix wrapper-lg">
        
        <div class="container text-center m-t-xl m-b-xl" data-ride="animated" data-animation="fadeIn">
          
          <h2>
            Newsletter
          </h2>
          
          <p>
            Do not want to miss anything? Subscribe to our newsletter box
          </p>
          
          <div class="form-inline m-t-xl m-b-xl">
            
            <div class="form-group">
              
              <input class="form-control input-lg news_letter" name="newsletter_email" placeholder="Your email" data-ride="animated" data-animation="fadeInLeftBig" data-delay="300">
              
            </div>
            
            <a  class="btn btn-default btn-lg news-lttr" data-ride="animated" data-animation="fadeInRightBig" data-delay="600">
              Subscribe
            </a>
			<div class="small-sp"></div>
			<p class="em-err"></p>
            
          </div>
          
        </div>
        
      </div>
    </section>
	
