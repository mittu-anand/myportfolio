<section class="scrollable wrapper">
                    
                    <div class="timeline">
                      
                      <article class="timeline-item active">
                        
                        <div class="timeline-caption">
                          
                          <div class="panel bg-primary lter no-borders">
                            
                            <div class="panel-body">
                             
                              <div class="m-t-sm timeline-action">
                                
                               
                                
                                <button class="btn btn-sm btn-default btn-bg">
                                  
                                 Latest Moviefeeds
                                </button>
                                <div class="btn-group">
  
  <button class="btn btn-success dropdown-toggle" data-toggle="dropdown">
    Language 
    <span class="caret">
    </span>
  </button>
  <input type="hidden" value="" class="urlstatus">
  <input type="hidden" value="Malayalam" class="urllanguage">
  <input type="hidden" value="5" class="limitdata">
  <ul class="dropdown-menu">
        <li>
      <a href="http://localhost/moviefolio/index.php/feeds/filter?language=Malayalam">
        Malayalam      </a>
    </li>
    
        <li>
      <a href="http://localhost/moviefolio/index.php/feeds/filter?language=Tamil">
        Tamil      </a>
    </li>
    
        <li>
      <a href="http://localhost/moviefolio/index.php/feeds/filter?language=Telugu">
        Telugu      </a>
    </li>
    
        <li>
      <a href="http://localhost/moviefolio/index.php/feeds/filter?language=Kannada">
        Kannada      </a>
    </li>
    
        <li>
      <a href="http://localhost/moviefolio/index.php/feeds/filter?language=Hindi">
        Hindi      </a>
    </li>
    
        <li>
      <a href="http://localhost/moviefolio/index.php/feeds/filter?language=English">
        English      </a>
    </li>
    
      </ul>
  
</div>
<div class="btn-group">
  
  <button class="btn btn-success dropdown-toggle" data-toggle="dropdown">
    Status 
    <span class="caret">
    </span>
  </button>
  
  <ul class="dropdown-menu">
  	<li>
      <a href="
	  
	  http://localhost/moviefolio/index.php/feeds/filter?status=inshoot&amp;&amp;language=Malayalam	  
	  ">
       In Shoot      </a>
    </li>
    	<li>
      <a href="
	  
	  http://localhost/moviefolio/index.php/feeds/filter?status=upcoming&amp;&amp;language=Malayalam	  
	  ">
       Up Coming      </a>
    </li>
    	<li>
      <a href="
	  
	  http://localhost/moviefolio/index.php/feeds/filter?status=nowrunning&amp;&amp;language=Malayalam	  
	  ">
       Now Running      </a>
    </li>
      </ul>
  
</div>
                              </div>
                              
                            </div>
                            
                          </div>
                          
                        </div>
                        
                      </article>
				
                                             <article class="timeline-item timlinefeed alt">
                        <input type="hidden" value="1" class="ifinder">
                        <div class="timeline-caption">
                          
                          <div class="panel panel-default">
                            
                            <div class="panel-body">
                              
                              <span class="arrow right">
                              </span>
                              
                              <span class="timeline-icon">
                                <i class="fa fa-bars time-icon bg-primary">
                                </i>
                              </span>
                              
                              <span class="timeline-date">
                                44 Years, 11 Months, 15 Hours, 23 Minutes ago                              </span>
                              
                              
                                
                                <span>
                                  <h5 style="font-weight:bold;padding-bottom:2px;color:#000;">sdfdfsdf</h5><h5>
                                
																<span style="padding-bottom:8px;">
								<p>
								
								sdfsfsfsf								</p>
								</span>
																                                <img src="http://localhost/moviefolio/uploads/moviepost/993909_vb.jpg" style="max-height:250px;max-width:500px;">
                                															  </h5>
                              <div style="margin:20px;">
                              <span style="box-sizing:0 !important;height:90px;" displaytext="Facebook" class="st_facebook_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="Tweet" class="st_twitter_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="LinkedIn" class="st_linkedin_hcount"></span>
							</div>
                            </span></div>
                            
                          </div>
                          
                        </div>
                        
                      </article>
					                        <article class="timeline-item timlinefeed ">
                        <input type="hidden" value="2" class="ifinder">
                        <div class="timeline-caption">
                          
                          <div class="panel panel-default">
                            
                            <div class="panel-body">
                              
                              <span class="arrow left">
                              </span>
                              
                              <span class="timeline-icon">
                                <i class="fa fa-bars time-icon bg-primary">
                                </i>
                              </span>
                              
                              <span class="timeline-date">
                                44 Years, 11 Months, 15 Hours, 23 Minutes ago                              </span>
                              
                              
                                
                                <span>
                                  <h5 style="font-weight:bold;padding-bottom:2px;color:#000;">gsgsdg</h5><h5>
                                
																<span style="padding-bottom:8px;">
								<p>
								
								sgdsdgdsgsdgsdg								</p>
								</span>
																                                <img src="http://localhost/moviefolio/uploads/moviepost/246408_325694807518704_1494180737_n.jpg" style="max-height:250px;max-width:500px;">
                                															  </h5>
                              <div style="margin:20px;">
                              <span style="box-sizing:0 !important;height:90px;" displaytext="Facebook" class="st_facebook_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="Tweet" class="st_twitter_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="LinkedIn" class="st_linkedin_hcount"></span>
							</div>
                            </span></div>
                            
                          </div>
                          
                        </div>
                        
                      </article>
					                        <article class="timeline-item timlinefeed alt">
                        <input type="hidden" value="3" class="ifinder">
                        <div class="timeline-caption">
                          
                          <div class="panel panel-default">
                            
                            <div class="panel-body">
                              
                              <span class="arrow right">
                              </span>
                              
                              <span class="timeline-icon">
                                <i class="fa fa-bars time-icon bg-primary">
                                </i>
                              </span>
                              
                              <span class="timeline-date">
                                44 Years, 11 Months, 15 Hours, 23 Minutes ago                              </span>
                              
                              
                                
                                <span>
                                  <h5 style="font-weight:bold;padding-bottom:2px;color:#000;">sdfsdfsfsfd</h5><h5>
                                
																<span style="padding-bottom:8px;">
								<p>
								
								sdfsdfsdf								</p>
								</span>
																                                <img src="http://localhost/moviefolio/uploads/moviepost/199519_1812112178439_1109044552_32006305_6621440_n1.jpg" style="max-height:250px;max-width:500px;">
                                															  </h5>
                              <div style="margin:20px;">
                              <span style="box-sizing:0 !important;height:90px;" displaytext="Facebook" class="st_facebook_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="Tweet" class="st_twitter_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="LinkedIn" class="st_linkedin_hcount"></span>
							</div>
                            </span></div>
                            
                          </div>
                          
                        </div>
                        
                      </article>
					                        <article class="timeline-item timlinefeed ">
                        <input type="hidden" value="4" class="ifinder">
                        <div class="timeline-caption">
                          
                          <div class="panel panel-default">
                            
                            <div class="panel-body">
                              
                              <span class="arrow left">
                              </span>
                              
                              <span class="timeline-icon">
                                <i class="fa fa-bars time-icon bg-primary">
                                </i>
                              </span>
                              
                              <span class="timeline-date">
                                44 Years, 11 Months, 15 Hours, 23 Minutes ago                              </span>
                              
                              
                                
                                <span>
                                  <h5 style="font-weight:bold;padding-bottom:2px;color:#000;">Here Comes the new trailor!</h5><h5>
                                
																																<div style="height:400px !important;width:400px !important;">
                                  
								   <iframe width="640" height="360" frameborder="0" allowfullscreen="" src="//www.youtube.com/embed/uVpHL5g4buY?feature=player_detailpage"></iframe>								</div>   
							   							  </h5>
                              <div style="margin:20px;">
                              <span style="box-sizing:0 !important;height:90px;" displaytext="Facebook" class="st_facebook_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="Tweet" class="st_twitter_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="LinkedIn" class="st_linkedin_hcount"></span>
							</div>
                            </span></div>
                            
                          </div>
                          
                        </div>
                        
                      </article>
					                        <article class="timeline-item timlinefeed alt">
                        <input type="hidden" value="5" class="ifinder">
                        <div class="timeline-caption">
                          
                          <div class="panel panel-default">
                            
                            <div class="panel-body">
                              
                              <span class="arrow right">
                              </span>
                              
                              <span class="timeline-icon">
                                <i class="fa fa-bars time-icon bg-primary">
                                </i>
                              </span>
                              
                              <span class="timeline-date">
                                44 Years, 11 Months, 15 Hours, 23 Minutes ago                              </span>
                              
                              
                                
                                <span>
                                  <h5 style="font-weight:bold;padding-bottom:2px;color:#000;">Bangalore days on its way!</h5><h5>
                                
																<span style="padding-bottom:8px;">
								<p>
								
								ssdfsdfsdfsdfsdf								</p>
								</span>
																															  </h5>
                              <div style="margin:20px;">
                              <span style="box-sizing:0 !important;height:90px;" displaytext="Facebook" class="st_facebook_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="Tweet" class="st_twitter_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="LinkedIn" class="st_linkedin_hcount"></span>
							</div>
                            </span></div>
                            
                          </div>
                          
                        </div>
                        
                                                             <article class="timeline-item timlinefeed ">
                         <input type="hidden" value="6" class="ifinder">
                        <div class="timeline-caption">
                          
                          <div class="panel panel-default">
                            
                            <div class="panel-body">
                              
                              <span class="arrow left">
                              </span>
                              
                              <span class="timeline-icon">
                                <i class="fa fa-bars time-icon bg-primary">
                                </i>
                              </span>
                              
                              <span class="timeline-date">
                                44 Years, 11 Months, 15 Hours, 25 Minutes ago                              </span>
                              
                              
                                
                                <span>
                                  <h5 style="font-weight:bold;padding-bottom:2px;color:#000;">who is your favourite star?? every one uhh???</h5><h5>
                                
																<span style="padding-bottom:8px;">
								<p>
								
								the stunning stars of bangalore days								</p>
								</span>
																                                <img src="http://localhost/moviefolio/uploads/moviepost/images.jpg" style="max-height:250px;max-width:500px;">
                                															  </h5>
                              <div style="margin:20px;">
                              <span style="box-sizing:0 !important;height:90px;" displaytext="Facebook" class="st_facebook_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="Tweet" class="st_twitter_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="LinkedIn" class="st_linkedin_hcount"></span>
							</div>
                            </span></div>
                            
                          </div>
                          
                        </div>
                        
                      </article>
					                        <article class="timeline-item timlinefeed alt">
                         <input type="hidden" value="7" class="ifinder">
                        <div class="timeline-caption">
                          
                          <div class="panel panel-default">
                            
                            <div class="panel-body">
                              
                              <span class="arrow right">
                              </span>
                              
                              <span class="timeline-icon">
                                <i class="fa fa-bars time-icon bg-primary">
                                </i>
                              </span>
                              
                              <span class="timeline-date">
                                44 Years, 11 Months, 15 Hours, 25 Minutes ago                              </span>
                              
                              
                                
                                <span>
                                  <h5 style="font-weight:bold;padding-bottom:2px;color:#000;">Nevin, Nasriya and Parvathy!</h5><h5>
                                
																<span style="padding-bottom:8px;">
								<p>
								
								Bangalore days which is expected to be released by december of 2014,is a movie directed by Anjali Menon. A photo of the stars in during the shoot.								</p>
								</span>
																                                <img src="http://localhost/moviefolio/uploads/moviepost/Nivin-Pauly-Nazriya-Nazim-Parvathi-Menon37201440221AM.jpg" style="max-height:250px;max-width:500px;">
                                															  </h5>
                              <div style="margin:20px;">
                              <span style="box-sizing:0 !important;height:90px;" displaytext="Facebook" class="st_facebook_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="Tweet" class="st_twitter_hcount"></span>
<span style="box-sizing:0 !important;" displaytext="LinkedIn" class="st_linkedin_hcount"></span>
							</div>
                            </span></div>
                            
                          </div>
                          
                        </div>
                        
                      </article>
					  					  </article>
					                        
                     
                      
                      
                      <div class="timeline-footer">
                        <a class="tests" href="#">
                          <i class="fa fa-plus time-icon inline-block bg-dark">
                          </i>
                        </a>
                      </div>
                   
                    </div>
                    
                  </section>