
          
          <!-- /.aside -->
        <?php if(isset($content)){echo $content[0]->terms;} ?>
       
        </section>
        
      </section>
      
    </section>
    