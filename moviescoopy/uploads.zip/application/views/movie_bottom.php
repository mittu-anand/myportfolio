 <!-- /.aside -->
              <!--------case of left menu------>
            </section>
            
            <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen, open" data-target="#nav,html">
            </a>
            
          </section>
          
          <aside class="bg-light lter b-l aside-md hide" id="notes">
            
            <div class="wrapper">
              Notification
            </div>
            
          </aside>
          
        </section>
        
      </section>
      
    </section>
    <style>

.stMainServices
{
 height:30px !important;
}
.stHBubble
{
height:23px !important;
}
</style>

<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "9ba88e3f-a5e7-4e33-bbc6-7662ecca4de2", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
