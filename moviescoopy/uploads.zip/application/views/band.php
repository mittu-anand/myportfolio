
<section class="vbox" >

      <section>
        
        <section class="hbox stretch">
          
          
          <section id="content">
            
            <section class="hbox stretch">
<div class="row">


<div class="spacer"></div>
  <div class="col-md-8 col-md-offset-2">
	
<section class="panel panel-default">
 
  <img src="http://localhost/moviescoopy.com/uploads/movie_other/bg1.jpg" style="max-height:300px;width:100%;">
  <footer class="panel-footer bg-white no-padder"> <div class="row text-center no-gutter"> 
  <div class="col-xs-3 b-r b-light"> <span class="h4 font-bold m-t block">5,860</span> <small class="text-muted m-b block">Orders</small> </div> 
  <div class="col-xs-3 b-r b-light"> <span class="h4 font-bold m-t block">10,450</span> <small class="text-muted m-b block">Sellings</small> </div>
  <div class="col-xs-3 b-r b-light"> <span class="h4 font-bold m-t block">21,230</span> <small class="text-muted m-b block">Items</small> </div>
  <div class="col-xs-3"> <span class="h4 font-bold m-t block">7,230</span>
  <small class="text-muted m-b block">Customers</small> </div> </div> </footer>
  
 
</section>
<div class="spacer"></div>
  <section class="chat-list panel-body">
  <div class="row">
   <div class="col-md-2">
   <a href="" class="btn btn-success btn-xs">Home</a>
   <a href="" class="btn btn-default  btn-xs">Tasks</a>
  </div>
  <div class="col-md-6">
  sdf
  </div>
   </div>
  </section>
  
	</div>
	
</div>
<div class="spacer"></div>
	<div class="spacer"></div>
</section>
</section>
</section>
</section>
</section>