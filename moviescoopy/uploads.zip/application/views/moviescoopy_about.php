
          
          <!-- /.aside -->
        <?php if(isset($content)){echo $content[0]->about;} ?>
       
        </section>
        
      </section>
      
    </section>
    